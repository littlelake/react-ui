import FooterTest from './footer';

export {
  FooterTest,
}