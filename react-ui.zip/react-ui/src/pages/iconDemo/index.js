import IconTest from './icon';

export {
  IconTest,
}