## 目录结构
```bash
+____common               # 通用js目录
+____components           # 组件目录
+____pages                # 页面目录
+____styles               # 样式目录
|____README.md            # 说明文档
|____app.jsx              # SPA入口
|____index.html           # SPA页面模板文件
```